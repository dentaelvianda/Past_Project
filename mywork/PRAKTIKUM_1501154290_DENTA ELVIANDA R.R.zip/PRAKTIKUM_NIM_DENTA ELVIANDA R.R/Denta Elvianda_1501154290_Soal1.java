import java.util.Scanner;
public class Denta Elvianda_1501154290_Soal1
{
	
	public static void main(String [] args)
	{
	Scanner input=new Scanner(System.in);
	int j,i;
	System.out.print("Masukkan Nilai =");
	int masukkan=input.nextInt();
		for (i=1; i<=masukkan; i++){
		for (j=1; j<=i; j++){
		System.out.println("*");	
		}
		System.out.println(" ");
		}
	
	}
}
